package com.example.shoppinglist;

import android.provider.BaseColumns;

public class ShoppingContract {
    private ShoppingContract() {
    }

    public static final class ShoppingEntry implements BaseColumns {

        public static final String TABLE_NAME = "shoppingList";
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_AMOUNT = "amount";
        public static final String COLUMN_COST = "price";
        public static final String COLUMN_DESCRIPTION = "description";
        public static final String COLUMN_PURCHASE = "purchase";
        public static final String COLUMN_TIMESTAMP = "timestamp";
    }
}
