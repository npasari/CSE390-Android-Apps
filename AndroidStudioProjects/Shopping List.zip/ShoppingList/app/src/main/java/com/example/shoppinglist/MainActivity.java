package com.example.shoppinglist;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class MainActivity extends AppCompatActivity {

    private SQLiteDatabase mDatabase;
    private ShoppingAdapter mAdapter;
    private EditText mEditTextName;
    private EditText mEditTextCost;
    private EditText mEditTextDescription;
    private EditText mEditTextPurchase;
    private TextView mTextViewAmount;
    private int mAmount = 0;
    private ImageView img;

    //referred codinginflow videos to understand making of shopping list

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ShoppingDBHelper dbHelper = new ShoppingDBHelper(this);
        mDatabase = dbHelper.getWritableDatabase();

        RecyclerView recyclerView = findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new ShoppingAdapter(this, getAllItems());
        recyclerView.setAdapter(mAdapter);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                removeItem((long) viewHolder.itemView.getTag());
            }
        }).attachToRecyclerView(recyclerView);

        mEditTextName = findViewById(R.id.edittext_name);
        mTextViewAmount = findViewById(R.id.textview_amount);
        Button buttonIncrease = findViewById(R.id.button_increase);
        Button buttonDecrease = findViewById(R.id.button_decrease);
        Button buttonAdd = findViewById(R.id.button_add);
        mEditTextCost = findViewById(R.id.edittext_price);
        mEditTextDescription = findViewById(R.id.edittext_description);
        mEditTextPurchase = findViewById(R.id.edittext_purchased);
        img = findViewById(R.id.myimageView);

        buttonIncrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increase();
            }
        });
        buttonDecrease.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrease();
            }
        });
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addItem();
            }
        });
    }

    private void increase() {
        mAmount++;
        mTextViewAmount.setText(String.valueOf(mAmount));
    }

    private void decrease() {
        if (mAmount > 0) {
            mAmount--;
            mTextViewAmount.setText(String.valueOf(mAmount));
        }
    }

    private void addItem() {
        if (mEditTextName.getText().toString().trim().length() == 0 || mAmount == 0) {
            return;
        }
        String name = mEditTextName.getText().toString();
        String cost = mEditTextCost.getText().toString() + " $ only";
        String description = mEditTextDescription.getText().toString();
        String purchase = mEditTextPurchase.getText().toString() + " purchase";

        ContentValues cv = new ContentValues();
        cv.put(ShoppingContract.ShoppingEntry.COLUMN_NAME, name);
        cv.put(ShoppingContract.ShoppingEntry.COLUMN_AMOUNT, mAmount);
        cv.put(ShoppingContract.ShoppingEntry.COLUMN_COST, cost);
        cv.put(ShoppingContract.ShoppingEntry.COLUMN_DESCRIPTION, description);
        cv.put(ShoppingContract.ShoppingEntry.COLUMN_PURCHASE, purchase);
        mDatabase.insert(ShoppingContract.ShoppingEntry.TABLE_NAME, null, cv);
        mAdapter.swapCursor(getAllItems());

        mEditTextName.getText().clear();
        mEditTextCost.getText().clear();
        mEditTextDescription.getText().clear();
        mEditTextPurchase.getText().clear();

    }

    private void removeItem(long id) {
        mDatabase.delete(ShoppingContract.ShoppingEntry.TABLE_NAME,
                ShoppingContract.ShoppingEntry._ID + "=" + id, null);
        mAdapter.swapCursor(getAllItems());
    }

    private Cursor getAllItems() {
        return mDatabase.query(
                ShoppingContract.ShoppingEntry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                ShoppingContract.ShoppingEntry.COLUMN_TIMESTAMP + " DESC"
        );
    }

}





