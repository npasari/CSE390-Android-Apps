package com.example.calculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText firstnum, secnum;
    TextView result;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button5 = (Button) findViewById(R.id.plusbutton);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstnum = findViewById(R.id.FirstNumeditText);
                secnum = findViewById(R.id.SecNumeditText);
                result = findViewById(R.id.resultTextView);
                double num1 = Double.parseDouble(firstnum.getText().toString());
                double num2 = Double.parseDouble(secnum.getText().toString());
                double ans = (num1 + num2);
                result.setText("Ans: " + String.format("%.2f", ans));
                closekeyboard();
            }
        });
        Button button6 = (Button) findViewById(R.id.minusbutton);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstnum = findViewById(R.id.FirstNumeditText);
                secnum = findViewById(R.id.SecNumeditText);
                result = findViewById(R.id.resultTextView);
                double num1 = Double.parseDouble(firstnum.getText().toString());
                double num2 = Double.parseDouble(secnum.getText().toString());
                double ans = (num2 - num1);
                result.setText("Ans: " + String.format("%.2f", ans));
                closekeyboard();

            }
        });
        Button button7 = (Button) findViewById(R.id.multbutton);
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstnum = findViewById(R.id.FirstNumeditText);
                secnum = findViewById(R.id.SecNumeditText);
                result = findViewById(R.id.resultTextView);
                double num1 = Double.parseDouble(firstnum.getText().toString());
                double num2 = Double.parseDouble(secnum.getText().toString());
                double ans = (num1 * num2);
                result.setText("Ans: " + String.format("%.2f", ans));
                closekeyboard();
            }
        });
        Button button8 = (Button) findViewById(R.id.dividebutton);
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                firstnum = findViewById(R.id.FirstNumeditText);
                secnum = findViewById(R.id.SecNumeditText);
                result = findViewById(R.id.resultTextView);
                float num1 = Float.parseFloat(firstnum.getText().toString());
                float num2 = Float.parseFloat(secnum.getText().toString());
                if (num2 == 0) {
                    try {
                        num2 = 0;
                        float ans = num1 / num2;
                        result.setText("Ans: This won't print! ");
                    } catch (ArithmeticException a) {
                        result.setText("Warning: Division by Zero isn't allowed");
                    }
                } else {
                    float ans = (num1 / num2);
                    result.setText("Ans: " + String.format("%.2f", ans));
                    closekeyboard();
                }
            }
        });
    }
    private void closekeyboard(){
        View view = this.getCurrentFocus();
        if(view != null){
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            assert imm != null;
            imm.hideSoftInputFromWindow(view.getWindowToken(),0);
        }
    }
}
