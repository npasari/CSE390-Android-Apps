package com.example.highlowgame;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private EditText firstnumEditText;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button Gbutton = (Button) findViewById(R.id.Guessbutton);
        Gbutton.setOnClickListener(new View.OnClickListener() {
            Random r = new Random();
            int comprand = r.nextInt(10);
            @Override
            public void onClick(View v) {
                firstnumEditText = findViewById(R.id.firstNumEditText);
                resultTextView = findViewById(R.id.resultTextView);
                int num = Integer.parseInt(firstnumEditText.getText().toString());
                if (num > comprand) {
                    resultTextView.setText("Your guess is too high");
                } else if (num < comprand) {
                    resultTextView.setText("Your guess is too low");
                } else {
                    resultTextView.setText("Your guess is correct!");
                }
            }
        });
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                startActivity(getIntent());
            }
        });
    }
}
