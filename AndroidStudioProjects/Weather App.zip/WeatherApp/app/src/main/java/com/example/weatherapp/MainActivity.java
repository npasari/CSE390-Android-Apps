package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    EditText cityCheck;
    ImageView iconimage;
    TextView cityname, cityTemp, cond, rise, set;

    class WeatherInfo extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL(params[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.connect();
                InputStream IS = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(IS);

                int data = reader.read();
                String APIdetails = "";
                char current;

                while (data != -1) {
                    current = (char) data;
                    APIdetails += current;
                    data = reader.read();
                }
                return APIdetails;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


    public void getWeatherAppInfo(View view) {
        WeatherInfo weatherInfo = new WeatherInfo();
        cityCheck = findViewById(R.id.editText);
        cityname = findViewById(R.id.CityNameTextView);
        cityTemp = findViewById(R.id.TempTextView);
        TextView unitTemp = (TextView) findViewById(R.id.UnitTemp);
        unitTemp.setText("°C");
        cond = (TextView) findViewById(R.id.CondtextView);
        iconimage = findViewById(R.id.icon);
        rise = findViewById(R.id.SunrisetextView);
        set = findViewById(R.id.SunsetTextView);

        try {
            String weatherAppdetails = weatherInfo.execute("https://api.openweathermap.org/data/2.5/weather?q="
                    + cityCheck.getText().toString() + "&appid=c263469652cac2d29a23d92a63ca3116").get();


            JSONObject jsonObject = new JSONObject(weatherAppdetails);
            String weather = jsonObject.getString("weather");
            String temp = jsonObject.getJSONObject("main").getString("temp");
            String naming = jsonObject.getString("name");
            String sunrise = jsonObject.getJSONObject("sys").getString("sunrise");
            String sunset = jsonObject.getJSONObject("sys").getString("sunset");


            double foo = Double.parseDouble(temp);
            int f = (int) (foo - 273.15);
            temp = Integer.toString(f);


            JSONArray jsonArray = new JSONArray(weather);
            String description = "";
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject arrayObject = jsonArray.getJSONObject(i);
                description = arrayObject.getString("description");
            }
            cityname.setText(naming);
            cond.setText(description);
            cityTemp.setText(temp);
            iconimage.setImageResource(R.drawable.cloud);
            rise.setText(sunrise);
            set.setText(sunset);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}
